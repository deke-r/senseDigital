import React from 'react'

const FacebookAdsManagement = () => {
  return (
    <div>page</div>
  )
}

export default FacebookAdsManagement