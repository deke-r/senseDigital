import React from 'react'

const ECommerceSeo = () => {
  return (
    <div>e-commerce-seo</div>
  )
}

export default ECommerceSeo