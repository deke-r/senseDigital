import React from 'react'

const LocalSeo = () => {
  return (
    <div>local-seo</div>
  )
}

export default LocalSeo