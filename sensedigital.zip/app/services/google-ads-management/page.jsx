import React from 'react'

const GAM = () => {
  return (
    <div>page</div>
  )
}

export default GAM