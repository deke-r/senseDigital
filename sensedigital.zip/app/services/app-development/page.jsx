import styles from "../../../styles/pages/services.module.css"
import { Smartphone, Code, Users, Zap, Shield, Headphones } from "lucide-react"

export default function AppDevelopmentPage() {
  return (
    <main className="container my-5">
      {/* Hero Section */}
      <section className={styles.heroSection}>
        <div className="row align-items-center">
          <div className="col-lg-6">
            <h1 className={styles.pageTitle}>App Development</h1>
            <p className={styles.heroSubtitle}>
              We create cutting-edge mobile applications for iOS and Android platforms, 
              focusing on intuitive design and robust performance that drives user engagement.
            </p>
            <div className={styles.heroActions}>
              <button className={styles.primaryBtn}>Get Started</button>
              <button className={styles.secondaryBtn}>View Portfolio</button>
            </div>
          </div>
          <div className="col-lg-6">
            <img
              src="/placeholder.svg?height=400&width=500"
              alt="App Development"
              className={`img-fluid ${styles.heroImage}`}
            />
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className={styles.servicesSection}>
        <div className="row">
          <div className="col-12 text-center mb-5">
            <h2 className={styles.sectionTitle}>Our App Development Services</h2>
            <p className={styles.sectionSubtitle}>
              From concept to launch, we provide comprehensive mobile app development solutions.
            </p>
          </div>
        </div>
        
        <div className="row g-4">
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Smartphone className={styles.serviceIcon} />
              <h3>Native iOS Development</h3>
              <p>High-performance iOS apps built with Swift and Objective-C, optimized for iPhone and iPad devices.</p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Code className={styles.serviceIcon} />
              <h3>Native Android Development</h3>
              <p>Robust Android applications developed with Kotlin and Java, ensuring compatibility across devices.</p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Users className={styles.serviceIcon} />
              <h3>Cross-Platform Development</h3>
              <p>React Native and Flutter solutions for cost-effective apps that work on both platforms.</p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Zap className={styles.serviceIcon} />
              <h3>UI/UX Design</h3>
              <p>Intuitive and engaging user interfaces designed to provide exceptional user experiences.</p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Shield className={styles.serviceIcon} />
              <h3>Backend Integration</h3>
              <p>Secure and scalable backend solutions with APIs, databases, and cloud infrastructure.</p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className={styles.serviceCard}>
              <Headphones className={styles.serviceIcon} />
              <h3>Ongoing Support</h3>
              <p>Comprehensive maintenance, updates, and technical support to keep your app running smoothly.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className={styles.processSection}>
        <div className="row">
          <div className="col-12 text-center mb-5">
            <h2 className={styles.sectionTitle}>Our Development Process</h2>
            <p className={styles.sectionSubtitle}>
              A proven methodology that ensures successful app delivery.
            </p>
          </div>
        </div>
        
        <div className="row">
          <div className="col-lg-3 col-md-6 mb-4">
            <div className={styles.processCard}>
              <div className={styles.processNumber}>01</div>
              <h4>Discovery & Planning</h4>
              <p>We analyze your requirements, define the scope, and create a detailed project roadmap.</p>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 mb-4">
            <div className={styles.processCard}>
              <div className={styles.processNumber}>02</div>
              <h4>Design & Prototyping</h4>
              <p>Our designers create wireframes, mockups, and interactive prototypes for your approval.</p>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 mb-4">
            <div className={styles.processCard}>
              <div className={styles.processNumber}>03</div>
              <h4>Development & Testing</h4>
              <p>We build your app using agile methodology with continuous testing and quality assurance.</p>
            </div>
          </div>
          <div className="col-lg-3 col-md-6 mb-4">
            <div className={styles.processCard}>
              <div className={styles.processNumber}>04</div>
              <h4>Launch & Support</h4>
              <p>We help you launch your app and provide ongoing support and maintenance services.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.ctaSection}>
        <div className="row">
          <div className="col-12 text-center">
            <h2 className={styles.ctaTitle}>Ready to Build Your App?</h2>
            <p className={styles.ctaSubtitle}>
              Let's discuss your app idea and create a solution that exceeds your expectations.
            </p>
            <button className={styles.ctaButton}>Start Your Project</button>
          </div>
        </div>
      </section>
    </main>
  )
}
