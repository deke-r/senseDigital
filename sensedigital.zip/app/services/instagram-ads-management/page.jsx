import React from 'react'

const InstagramAdsManagement = () => {
  return (
    <div>page</div>
  )
}

export default InstagramAdsManagement