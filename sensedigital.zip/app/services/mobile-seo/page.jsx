import React from 'react'

const MobileSeo = () => {
  return (
    <div>mobile-seo</div>
  )
}

export default MobileSeo