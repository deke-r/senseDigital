import React from 'react'

const OnPageSeo = () => {
  return (
    <div>page</div>
  )
}

export default OnPageSeo