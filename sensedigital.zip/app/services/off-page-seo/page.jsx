import React from 'react'

const OffPageSeo = () => {
  return (
    <div>page</div>
  )
}

export default OffPageSeo