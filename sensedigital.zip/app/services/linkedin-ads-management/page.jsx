import React from 'react'

const LAM = () => {
  return (
    <div>page</div>
  )
}

export default LAM